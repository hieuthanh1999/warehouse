# coding: utf-8
from . import res_partner
from . import box_1099
