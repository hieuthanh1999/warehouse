# -*- coding: utf-8 -*-

from . import account_link_journal_wizard
