# -*- coding: utf-8 -*-

from . import stock_picking
from . import stock_quant
from . import stock_scrap
from . import stock_location
from . import stock_move_line
from . import stock_package_type
from . import stock_production_lot
from . import stock_quant_package
from . import product_product
from . import product_packaging
from . import res_config_settings
from . import res_partner
from . import uom_uom
