Fiscal Reports for Closing Entry
================================

Trial Balance report is complemented to generate the closing entry
(A.K.A Month 13th move)

Configuration
=============

Steps to get the report:

1. The journal entry for transfer of exercises must be generated manually
   with the end date of the fiscal year that is closing. And must be posted.

2. This entry must be marked as closing entry for the fiscal year.

3. The trial balance Month 13 report must be generated with dates for all the
   fiscal year to report.
