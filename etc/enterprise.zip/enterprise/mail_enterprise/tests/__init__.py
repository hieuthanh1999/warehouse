# -*- coding: utf-8 -*-

from . import test_mail_channel_expand
